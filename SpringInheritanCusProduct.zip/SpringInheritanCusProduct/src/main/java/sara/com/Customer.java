package sara.com;

public class Customer {
	int cid;
	String cname;
	String pname;
	public void getCid() {
		System.out.println("cid ="+cid);
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public void getCname() {
		System.out.println("cname ="+cname);
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public void getPname() {
		System.out.println("pname ="+pname);
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
}
