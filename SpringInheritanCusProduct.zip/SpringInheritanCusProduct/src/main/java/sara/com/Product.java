package sara.com;

public class Product {
int pid;
String pname;
public void getPid() {
	System.out.println("pid ="+pid);
}
public void setPid(int pid) {
	this.pid = pid;
}
public void getPname() {
	System.out.println("pname ="+pname);
}
public void setPname(String pname) {
	this.pname = pname;
}

}
