package sara.com;


public class MainApp {

	public static  void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("sara.xml");
	      
	      Product objA = (Product) context.getBean("pob");
	      
	      Customer objB = (Customer) context.getBean("cob");
	      objB.getCid();
	      objB.getCname();
	      objB.getPname();
	      objA.getPid();
	      objA.getPname();
       
	    

	}

}
