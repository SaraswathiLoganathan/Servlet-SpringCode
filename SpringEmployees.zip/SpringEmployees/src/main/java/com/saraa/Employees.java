package com.saraa;

public class Employees {
	private int eage;
	private String ename;
	private float esalary;
	
	
	public Employees(int eage, String ename, float esalary) {
		super();
		this.eage = eage;
		this.ename = ename;
		this.esalary = esalary;
	}


	public void display() {
		System.out.println("employee name="+ename);
		System.out.println("employee age="+eage);
		System.out.println("employee salary="+esalary);
	}
}
