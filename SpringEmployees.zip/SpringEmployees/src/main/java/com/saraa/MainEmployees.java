package com.saraa;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainEmployees {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Spring1.xml");
		
		Employees eob= (Employees) ctx.getBean("eobj");
		Employees eob1= (Employees) ctx.getBean("eobj1");
		eob.display();
		eob1.display();
		System.out.println("eob="+eob1);
	

	}

}
