package com.stu;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletStudentReg
 */
@WebServlet("/ServletStudentReg")
public class ServletStudentReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       public Connection myconn;
       PreparedStatement pst;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletStudentReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		myconn=DatabaseConn.getConnection();
		System.out.println("Check connection "+myconn);
		String n=request.getParameter("sname");
		String p=request.getParameter("spass");
		String em=request.getParameter("semail");
		int ag=Integer.parseInt(request.getParameter("sage"));
		PrintWriter out=response.getWriter();
		String sint="insert into studentreg values(?,?,?,?)";
		
			try {
				pst=myconn.prepareStatement(sint);
				pst.setString(1, n);
				pst.setString(2, p);
				pst.setString(3, em);
				pst.setInt(4, ag);
				int rv=pst.executeUpdate();
				if(rv>0)
				{
					out.println("Registered Successfully");
				}
			}
				catch (SQLException e) {
				
				
				e.printStackTrace();
			}
			
			
		
}
}