package stu.com;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
	public static Connection conn;
	public static String driver="com.mysql.cj.jdbc.Driver";
	public static String url="jdbc:mysql://localhost:3306/servletstudents";
	public static String un="root";
	public static String pass="root";
	public static Connection getConnection() {
	
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url,un,pass);
			
			if(conn==null) {
				System.out.println("Database connection error");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}

}
