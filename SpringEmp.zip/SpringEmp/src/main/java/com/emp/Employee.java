package com.emp;

public class Employee {
	public void display{
		System.out.println("student");
	}
	

}
