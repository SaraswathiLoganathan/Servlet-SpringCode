package com.emp;


public class EmpMainApp {

	public static void main(String[] args) {
	
		Employee sob=(Employee) ctx.getBean("");

	}

}
