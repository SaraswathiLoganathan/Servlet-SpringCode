package com.cal;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalculateMain
 */
@WebServlet("/CalculateMain")
public class CalculateMain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalculateMain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		double num1=Double.parseDouble(request.getParameter("n1"));
		double num2=Double.parseDouble(request.getParameter("n2"));
		double res=0;
		String butval=request.getParameter("op");
		
		switch(butval) {
		case "add":res = num1+num2;
				out.println("the sum of"+num1+" and "+num2+" is "+res);
				break;
		
		case "sub":res = num1-num2;
				out.println("the difference of"+num1+" and "+num2+" is "+res);
				break;
		
		case "mul":res = num1*num2;
				out.println("the product of"+num1+" and "+num2+" is "+res);
				break;
		
		case "div":
			if(num2!=0) {
				res = num1/num2;
				out.println("the difference of"+num1+" and "+num2+" is "+res);
			}else {
				out.print("divide zero error");
			}
				
				break;
		 
			
		}
		
	}

}
