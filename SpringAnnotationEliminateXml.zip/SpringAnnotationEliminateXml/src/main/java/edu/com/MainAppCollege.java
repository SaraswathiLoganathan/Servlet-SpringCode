package edu.com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainAppCollege {
	public static void main(String args) {
		ApplicationContext ctx=new AnnotationConfigApplicationContext(MyConfig.class);
		College cob=ctx.getBean("collegeBean",College.class);
		cob.display();
		System.out.println("object of college class "+cob);
	}

}
