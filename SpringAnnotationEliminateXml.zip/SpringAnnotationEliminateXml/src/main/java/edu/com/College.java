package edu.com;

import org.springframework.stereotype.Component;

@Component("collegeBean")  //collegeBean is an object
public class College {
	
	void display() {
		System.out.println("college class display");
	}

}
