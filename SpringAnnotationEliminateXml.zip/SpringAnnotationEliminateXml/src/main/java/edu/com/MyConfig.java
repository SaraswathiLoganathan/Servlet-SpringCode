package edu.com;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration  //tells spring this is configuration class //define here component-scan 
@ComponentScan(basePackages="edu.com") //spring from this packages

public class MyConfig {
	

}
