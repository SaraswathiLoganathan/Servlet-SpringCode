package eliminate.nml;

import org.springframework.stereotype.Component;

@Component("empBean")
public class Employee {
 void display() {
	 System.out.println("my employee");
 }
}
