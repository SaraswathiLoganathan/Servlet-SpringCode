package eliminate.nml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		
		ApplicationContext ct=new AnnotationConfigApplicationContext(ConfigCls.class);
		Employee ob=ct.getBean("empBean",Employee.class);
		ob.display();
		System.out.println("object of employee class "+ob);
		
		
		/*ApplicationContext ctx=new AnnotationConfigApplicationContext(MyConfig.class);
		College cob=ctx.getBean("collegeBean",College.class);
		cob.display();
		System.out.println("object of college class "+cob);*/
	}

}
