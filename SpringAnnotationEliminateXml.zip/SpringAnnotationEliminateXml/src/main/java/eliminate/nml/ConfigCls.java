package eliminate.nml;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="eliminate.nml")
public class ConfigCls {

}
