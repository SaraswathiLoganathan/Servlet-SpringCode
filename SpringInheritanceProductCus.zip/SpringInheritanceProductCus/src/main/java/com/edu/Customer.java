package com.edu;

public class Customer {
	
		 int cid;
		  String cname;
		   String pname;
		
		public void setCid(int cid) {
			this.cid = cid;
		}
		
		public void setCname(String cname) {
			this.cname = cname;
		}
		
		
		public void setPname(String pname) {
			this.pname = pname;
		}
		
		public void getCid() {
			System.out.println("Customer id ="+cid);
		}
		
		public void getPname() {
			System.out.println("Product id ="+pname);
		}
		
		public void getCname() {
			System.out.println("Customer name ="+cname);
		}

}
