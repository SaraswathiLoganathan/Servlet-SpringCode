package com.edu;

public class Product {
	
			   int pid;
			   String pname;
			
			public void setPid(int pid) {
				this.pid = pid;
			}
			
			public void setPname(String pname) {
				this.pname = pname;
			}
			
			public void getPname() {
				System.out.println("product name ="+pname);
			}
			
			public void getPid() {
			System.out.println("Product id ="+pid);
			}		  
}


