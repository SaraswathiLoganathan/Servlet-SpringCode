package com.edu;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("springs1.xml");
	      
	      Product objA = (Product) context.getBean("product");
	      objA.getPid();
	      objA.getPname();
         
	      Customer objB = (Customer) context.getBean("customer");
	      objB.getCid();
	      objB.getCname();
	      objB.getPname();
	    
	}

}
