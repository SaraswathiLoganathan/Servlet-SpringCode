
public class Employee {
	private int age;
	private String name;
	private String cname;
	public Employee(String name,int age,String cname) {
		System.out.println("Constructor is called");
		this.name=name;
		this.age=age;
		this.cname=cname;
		
	}
	
	public void display() {
		System.out.println("name="+name);
		System.out.println("age="+age);
		System.out.println("College name="+cname);
	}
}
