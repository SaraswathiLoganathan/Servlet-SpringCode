import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
g[] args) {
ApplicationContext ctx = new ClassPathXmlApplicationContext("Spring.xml");
		
		Student sob=(Student) ctx.getBean("studentob");
		Student sob1=(Student) ctx.getBean("studentob1");
		sob.display();
		sob1.display();
		System.out.println("sob="+sob1);
	}

}
