package com.saraa;

public class SpringLiCy {

	public SpringLiCy() {
		super();
		System.out.println("Constructor called");
	}

	public void init() {
		System.out.println("Init is called");
	}
	
	public void destroy() {
		System.out.println("destroy method is called");
	}
	
}
