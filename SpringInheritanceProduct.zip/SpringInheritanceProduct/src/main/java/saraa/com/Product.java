package saraa.com;

public class Product {
	int pid;
	String pname;
	public void getPid() {
		System.out.println("Product pid ="+pid);
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public void getPname() {
		System.out.println("Product pname ="+pname);
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
}
