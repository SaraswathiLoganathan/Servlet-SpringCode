package saraa.com;

public class Customer {
int cid;
String cname;
String pname;
public  void  getPname() {
	System.out.println("product name="+pname);
}
public void setPname(String pname) {
	this.pname = pname;
}
public void getCid() {
	System.out.println("Customer id ="+cid);
	
}
public void setCid(int cid) {
	this.cid = cid;
}
public void getCname() {
	 System.out.println("Customer name ="+cname);
	
}
public void setCname(String cname) {
	this.cname = cname;
}

}
