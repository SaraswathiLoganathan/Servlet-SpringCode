package com.sara;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Spring.xml");
		
		Student sob=(Student) ctx.getBean("studentob");
		Student sob1=(Student) ctx.getBean("studentob1");
		sob.display();
		sob1.display();
		System.out.println("sob="+sob1);
	

	}

}
