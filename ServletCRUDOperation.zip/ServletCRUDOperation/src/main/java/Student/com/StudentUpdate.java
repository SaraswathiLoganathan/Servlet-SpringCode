package Student.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentUpdate
 */
@WebServlet("/StudentUpdate")
public class StudentUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection myconn;
	private PreparedStatement pst;
	private ResultSet rs;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		//get the data from HTML like reading data from scanner in core
		String em=request.getParameter("email");
		String n=request.getParameter("name");
		
		//for update check email id exists
		try {
		myconn=DatabaseConnection.getConnection();
		String sel = "select * from student where email=?";
		
		pst= myconn.prepareStatement(sel);
		pst.setString(1, em);
		rs=pst.executeQuery();
		
		if(rs.next()) { //if emailid exists the go for update
			String upd="update student set name=? where email=?";
			pst=myconn.prepareStatement(upd);
			pst.setString(1, n);
			pst.setString(2, em);
			
			int reval=pst.executeUpdate();
			
			if(reval>0) {
				out.println("name is changed successfully");
			}else {
				out.println("Error in changing name");
			}
			
		}else {
			out.println("Email id not Exists");
		}
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}


}
