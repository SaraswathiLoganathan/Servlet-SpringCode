package com.sara;

public class Product {
	private int pid;
	private String pname;
	private float pprice;
	
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public float getPprice() {
	return pprice;
}
public void setPprice(float pprice) {
	this.pprice = pprice;
}


 void display() {
	System.out.println("Product name="+pname);
	System.out.println("Product price="+pprice);
	System.out.println("Product id="+pid);
}

	}

